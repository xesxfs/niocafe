window.skins={};
                function __extends(d, b) {
                    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
                        function __() {
                            this.constructor = d;
                        }
                    __.prototype = b.prototype;
                    d.prototype = new __();
                };
                window.generateEUI = {};
                generateEUI.paths = {};
                generateEUI.styles = undefined;
                generateEUI.skins = {"eui.Button":"resource/eui_skins/ButtonSkin.exml","Bottle":"resource/eui_skins/BottleSkin.exml","BigMachine":"resource/eui_skins/BigMachineSkin.exml","BigCup":"resource/eui_skins/BigCupSkin.exml","SmallMachine":"resource/eui_skins/SmallMachineSkin.exml","SmallCup":"resource/eui_skins/SmallCupSkin.exml","OrderUI":"resource/eui_skins/OrderUISkin.exml","FoodOrder":"resource/eui_skins/FoodOrderSkin.exml","BeginUI":"resource/eui_skins/BeginUISkin.exml"};generateEUI.paths['resource/eui_skins/BeginUISkin.exml'] = window.BeginUISkin = (function (_super) {
	__extends(BeginUISkin, _super);
	function BeginUISkin() {
		_super.call(this);
		this.skinParts = ["beginBtn"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.beginBtn_i()];
	}
	var _proto = BeginUISkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "begin_bg_png";
		t.top = 0;
		return t;
	};
	_proto.beginBtn_i = function () {
		var t = new eui.Button();
		this.beginBtn = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 111;
		t.height = 80;
		t.label = "";
		t.width = 448;
		t.x = 151;
		return t;
	};
	return BeginUISkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/BigCupSkin.exml'] = window.BigCupSkin = (function (_super) {
	__extends(BigCupSkin, _super);
	function BigCupSkin() {
		_super.call(this);
		this.skinParts = ["scuping00","sfull","scuping","smask","scupingmk","sfree","sfullwhater","swhater","scup","bfull","bcuping","bcupingmk","bfree","bmask","bfullwhater","bwhater","bcup"];
		
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = BigCupSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.height = 146;
		t.width = 130;
		t.elementsContent = [this.scup_i(),this.bcup_i()];
		return t;
	};
	_proto.scup_i = function () {
		var t = new eui.Group();
		this.scup = t;
		t.height = 146;
		t.visible = false;
		t.width = 130;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.scuping00_i(),this.sfull_i(),this.scuping_i(),this.smask_i(),this.scupingmk_i(),this.sfree_i(),this.sfullwhater_i(),this.swhater_i()];
		return t;
	};
	_proto.scuping00_i = function () {
		var t = new eui.Image();
		this.scuping00 = t;
		t.anchorOffsetX = 0;
		t.bottom = -4;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.top = 24;
		t.x = 0;
		t.y = 20;
		return t;
	};
	_proto.sfull_i = function () {
		var t = new eui.Image();
		this.sfull = t;
		t.bottom = 0;
		t.left = 3;
		t.right = 3;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete0_png";
		t.top = 20;
		t.visible = false;
		t.x = 3;
		t.y = 20;
		return t;
	};
	_proto.scuping_i = function () {
		var t = new eui.Image();
		this.scuping = t;
		t.anchorOffsetX = 0;
		t.height = 126;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.y = 24;
		return t;
	};
	_proto.smask_i = function () {
		var t = new eui.Image();
		this.smask = t;
		t.anchorOffsetY = 0;
		t.height = 120;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.width = 116;
		t.x = 7;
		t.y = 20;
		return t;
	};
	_proto.scupingmk_i = function () {
		var t = new eui.Image();
		this.scupingmk = t;
		t.anchorOffsetX = 0;
		t.bottom = -4;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.top = 24;
		t.visible = false;
		t.x = 0;
		t.y = 20;
		return t;
	};
	_proto.sfree_i = function () {
		var t = new eui.Image();
		this.sfree = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete1_png";
		t.top = 20;
		t.visible = false;
		t.x = 1;
		t.y = 20;
		return t;
	};
	_proto.sfullwhater_i = function () {
		var t = new eui.Rect();
		this.sfullwhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x7c2f2f;
		t.height = 2;
		t.mask = this.scuping;
		t.width = 130;
		t.x = 0;
		t.y = 31;
		return t;
	};
	_proto.swhater_i = function () {
		var t = new eui.Rect();
		this.swhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 3;
		t.fillColor = 0x3c0000;
		t.height = 2;
		t.left = 0;
		t.right = 0;
		return t;
	};
	_proto.bcup_i = function () {
		var t = new eui.Group();
		this.bcup = t;
		t.height = 146;
		t.width = 130;
		t.x = 0;
		t.y = 0;
		t.elementsContent = [this.bfull_i(),this.bcuping_i(),this.bcupingmk_i(),this.bfree_i(),this.bmask_i(),this.bfullwhater_i(),this.bwhater_i()];
		return t;
	};
	_proto.bfull_i = function () {
		var t = new eui.Image();
		this.bfull = t;
		t.bottom = 0;
		t.left = 8;
		t.right = 8;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete0_png";
		t.top = 0;
		t.visible = false;
		t.x = 8;
		t.y = 0;
		return t;
	};
	_proto.bcuping_i = function () {
		var t = new eui.Image();
		this.bcuping = t;
		t.bottom = -4;
		t.left = 8;
		t.right = 8;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.top = 4;
		t.x = 8;
		t.y = 0;
		return t;
	};
	_proto.bcupingmk_i = function () {
		var t = new eui.Image();
		this.bcupingmk = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 141;
		t.horizontalCenter = 0.5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.width = 115;
		t.y = -4;
		return t;
	};
	_proto.bfree_i = function () {
		var t = new eui.Image();
		this.bfree = t;
		t.bottom = 0;
		t.left = 8;
		t.right = 8;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete1_png";
		t.top = 0;
		t.visible = false;
		t.x = 8;
		t.y = 0;
		return t;
	};
	_proto.bmask_i = function () {
		var t = new eui.Image();
		this.bmask = t;
		t.height = 136;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.width = 104;
		t.x = 14;
		t.y = 4;
		return t;
	};
	_proto.bfullwhater_i = function () {
		var t = new eui.Rect();
		this.bfullwhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x7C2F2F;
		t.height = 2;
		t.mask = this.scuping;
		t.width = 130;
		t.x = 0;
		t.y = 5;
		return t;
	};
	_proto.bwhater_i = function () {
		var t = new eui.Rect();
		this.bwhater = t;
		t.bottom = 2;
		t.fillColor = 0x3C0000;
		t.height = 2;
		t.mask = this.smask;
		t.width = 130;
		return t;
	};
	return BigCupSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/BigMachineSkin.exml'] = window.BigMachineSkin = (function (_super) {
	__extends(BigMachineSkin, _super);
	function BigMachineSkin() {
		_super.call(this);
		this.skinParts = ["notImg","inputImg","delImg","packageImg","operationGroup","cup","leftwhater","rightwhater","fd2","fd1","sfull","bfull","sdel","bdel","xxx"];
		
		this.height = 484;
		this.width = 571;
		this.elementsContent = [this._Group4_i()];
	}
	var _proto = BigMachineSkin.prototype;

	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.height = 484;
		t.width = 571;
		t.elementsContent = [this._Image1_i(),this.operationGroup_i(),this.cup_i(),this.leftwhater_i(),this.rightwhater_i(),this._Group1_i(),this._Group2_i(),this._Group3_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cafe_png";
		return t;
	};
	_proto.operationGroup_i = function () {
		var t = new eui.Group();
		this.operationGroup = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 187;
		t.width = 126;
		t.x = 228;
		t.y = 60;
		t.elementsContent = [this.notImg_i(),this.inputImg_i(),this.delImg_i(),this.packageImg_i()];
		return t;
	};
	_proto.notImg_i = function () {
		var t = new eui.Image();
		this.notImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon66_noinput_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.inputImg_i = function () {
		var t = new eui.Image();
		this.inputImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_input_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.delImg_i = function () {
		var t = new eui.Image();
		this.delImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_del_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.packageImg_i = function () {
		var t = new eui.Image();
		this.packageImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_cafe_input_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.cup_i = function () {
		var t = new BigCup();
		this.cup = t;
		t.x = 225;
		t.y = 329.34;
		return t;
	};
	_proto.leftwhater_i = function () {
		var t = new eui.Image();
		this.leftwhater = t;
		t.height = 198;
		t.source = "cafe_whatering_png";
		t.x = 259;
		t.y = 271;
		return t;
	};
	_proto.rightwhater_i = function () {
		var t = new eui.Image();
		this.rightwhater = t;
		t.height = 198;
		t.source = "cafe_whatering_png";
		t.x = 315;
		t.y = 271;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 123;
		t.width = 65;
		t.x = 256;
		t.y = 340;
		t.layout = this._VerticalLayout1_i();
		t.elementsContent = [this.fd2_i(),this.fd1_i()];
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		t.horizontalAlign = "center";
		t.paddingBottom = 5;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.fd2_i = function () {
		var t = new eui.Image();
		this.fd2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 43;
		t.source = "";
		t.width = 47;
		t.x = 4;
		t.y = 43;
		return t;
	};
	_proto.fd1_i = function () {
		var t = new eui.Image();
		this.fd1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 43;
		t.source = "";
		t.width = 47;
		t.x = 14;
		t.y = 53;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 146;
		t.width = 159.5;
		t.x = 206;
		t.y = 329.5;
		t.layout = this._BasicLayout1_i();
		t.elementsContent = [this.sfull_i(),this.bfull_i()];
		return t;
	};
	_proto._BasicLayout1_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sfull_i = function () {
		var t = new eui.Image();
		this.sfull = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = -3;
		t.height = 125.5;
		t.horizontalCenter = 2;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete0_png";
		t.visible = false;
		t.width = 138;
		return t;
	};
	_proto.bfull_i = function () {
		var t = new eui.Image();
		this.bfull = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 147.5;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete0_png";
		t.verticalCenter = 0;
		t.visible = false;
		t.width = 126.5;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 146;
		t.width = 130;
		t.x = 223.5;
		t.y = 328.5;
		t.layout = this._BasicLayout2_i();
		t.elementsContent = [this.sdel_i(),this.bdel_i(),this.xxx_i()];
		return t;
	};
	_proto._BasicLayout2_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sdel_i = function () {
		var t = new eui.Image();
		this.sdel = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = -5;
		t.height = 126;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.width = 130;
		return t;
	};
	_proto.bdel_i = function () {
		var t = new eui.Image();
		this.bdel = t;
		t.bottom = -2;
		t.height = 146;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.visible = false;
		t.width = 114;
		return t;
	};
	_proto.xxx_i = function () {
		var t = new eui.Image();
		this.xxx = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "xxx_png";
		t.verticalCenter = 9;
		t.visible = false;
		return t;
	};
	return BigMachineSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/BottleSkin.exml'] = window.BottleSkin = (function (_super) {
	__extends(BottleSkin, _super);
	function BottleSkin() {
		_super.call(this);
		this.skinParts = ["foodImg"];
		
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = BottleSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this._Image1_i(),this.foodImg_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "bottle_png";
		return t;
	};
	_proto.foodImg_i = function () {
		var t = new eui.Image();
		this.foodImg = t;
		t.horizontalCenter = 0;
		t.source = "chestnut_png";
		t.verticalCenter = 0;
		return t;
	};
	return BottleSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ButtonSkin.exml'] = window.skins.ButtonSkin = (function (_super) {
	__extends(ButtonSkin, _super);
	function ButtonSkin() {
		_super.call(this);
		this.skinParts = ["labelDisplay"];
		
		this.minHeight = 50;
		this.minWidth = 100;
		this.elementsContent = [this.labelDisplay_i()];
		this.states = [
			new eui.State ("up",
				[
				])
			,
			new eui.State ("down",
				[
				])
			,
			new eui.State ("disabled",
				[
				])
		];
	}
	var _proto = ButtonSkin.prototype;

	_proto.labelDisplay_i = function () {
		var t = new eui.Label();
		this.labelDisplay = t;
		t.bottom = 8;
		t.left = 8;
		t.right = 8;
		t.size = 20;
		t.textAlign = "center";
		t.textColor = 0xFFFFFF;
		t.top = 8;
		t.verticalAlign = "middle";
		return t;
	};
	return ButtonSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/FoodOrderSkin.exml'] = window.FoodOrderSkin = (function (_super) {
	__extends(FoodOrderSkin, _super);
	function FoodOrderSkin() {
		_super.call(this);
		this.skinParts = ["o1","one","t1","t2","two"];
		
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = FoodOrderSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.scaleX = 1;
		t.scaleY = 1;
		t.elementsContent = [this._Image1_i(),this.one_i(),this.two_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "game_order_bg_png";
		return t;
	};
	_proto.one_i = function () {
		var t = new eui.Group();
		this.one = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.o1_i()];
		return t;
	};
	_proto.o1_i = function () {
		var t = new eui.Image();
		this.o1 = t;
		t.horizontalCenter = 0;
		t.source = "nut_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.two_i = function () {
		var t = new eui.Group();
		this.two = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this.t1_i(),this.t2_i()];
		return t;
	};
	_proto.t1_i = function () {
		var t = new eui.Image();
		this.t1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 52;
		t.source = "nut_png";
		t.width = 51;
		t.x = 14;
		t.y = 14;
		return t;
	};
	_proto.t2_i = function () {
		var t = new eui.Image();
		this.t2 = t;
		t.source = "nut_png";
		t.x = 43;
		t.y = 59;
		return t;
	};
	return FoodOrderSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/GameSkin.exml'] = window.GameSkin = (function (_super) {
	__extends(GameSkin, _super);
	var GameSkin$Skin1 = 	(function (_super) {
		__extends(GameSkin$Skin1, _super);
		function GameSkin$Skin1() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = GameSkin$Skin1.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "left_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return GameSkin$Skin1;
	})(eui.Skin);

	var GameSkin$Skin2 = 	(function (_super) {
		__extends(GameSkin$Skin2, _super);
		function GameSkin$Skin2() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = GameSkin$Skin2.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "right_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return GameSkin$Skin2;
	})(eui.Skin);

	function GameSkin() {
		_super.call(this);
		this.skinParts = ["sm1","sm2","sm3","sm4","sm5","sm6","bigMachine","orderUI1","orderUI2","sm7","sm8","sm9","sm10","sm11","sm12","midGroup","bt1","bt2","bt3","bt4","bt5","bottomGroup","cdGroup1","cdGroup0","cdGroup","leftBtn","rightBtn","timeLab","scoreLab"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group14_i()];
	}
	var _proto = GameSkin.prototype;

	_proto._Group14_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this.midGroup_i(),this.bottomGroup_i(),this.cdGroup1_i(),this.cdGroup0_i(),this.cdGroup_i(),this.leftBtn_i(),this.rightBtn_i(),this._Group13_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "bg_png";
		t.top = 0;
		return t;
	};
	_proto.midGroup_i = function () {
		var t = new eui.Group();
		this.midGroup = t;
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.visible = false;
		t.layout = this._HorizontalLayout1_i();
		t.elementsContent = [this._Group4_i(),this._Group5_i(),this._Group9_i()];
		return t;
	};
	_proto._HorizontalLayout1_i = function () {
		var t = new eui.HorizontalLayout();
		return t;
	};
	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.width = 750;
		t.x = -750;
		t.elementsContent = [this._Image2_i(),this._Group1_i(),this._Group2_i(),this._Group3_i()];
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "cafe_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 156.68;
		t.layout = this._BasicLayout1_i();
		t.elementsContent = [this.sm1_i(),this.sm2_i()];
		return t;
	};
	_proto._BasicLayout1_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm1_i = function () {
		var t = new SmallMachine();
		this.sm1 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm2_i = function () {
		var t = new SmallMachine();
		this.sm2 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 494.58;
		t.layout = this._BasicLayout2_i();
		t.elementsContent = [this.sm3_i(),this.sm4_i()];
		return t;
	};
	_proto._BasicLayout2_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm3_i = function () {
		var t = new SmallMachine();
		this.sm3 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm4_i = function () {
		var t = new SmallMachine();
		this.sm4 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 833.97;
		t.layout = this._BasicLayout3_i();
		t.elementsContent = [this.sm5_i(),this.sm6_i()];
		return t;
	};
	_proto._BasicLayout3_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm5_i = function () {
		var t = new SmallMachine();
		this.sm5 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm6_i = function () {
		var t = new SmallMachine();
		this.sm6 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto._Group5_i = function () {
		var t = new eui.Group();
		t.anchorOffsetY = 0;
		t.bottom = 210;
		t.height = 1334;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.width = 750;
		t.x = 0;
		t.elementsContent = [this._Image3_i(),this._Image4_i(),this.bigMachine_i(),this.orderUI1_i(),this.orderUI2_i()];
		return t;
	};
	_proto._Image3_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.source = "logo_txt_png";
		t.top = 90;
		return t;
	};
	_proto._Image4_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 91.5;
		t.source = "game_txt_png";
		t.top = 161;
		return t;
	};
	_proto.bigMachine_i = function () {
		var t = new BigMachine();
		this.bigMachine = t;
		t.height = 484;
		t.horizontalCenter = 0.5;
		t.top = 566;
		t.width = 571;
		return t;
	};
	_proto.orderUI1_i = function () {
		var t = new OrderUI();
		this.orderUI1 = t;
		t.horizontalCenter = 0;
		t.top = 228;
		return t;
	};
	_proto.orderUI2_i = function () {
		var t = new OrderUI();
		this.orderUI2 = t;
		t.height = 154;
		t.horizontalCenter = 0;
		t.top = 398;
		t.width = 607;
		return t;
	};
	_proto._Group9_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.top = 0;
		t.width = 750;
		t.x = 750;
		t.elementsContent = [this._Image5_i(),this._Group6_i(),this._Group7_i(),this._Group8_i()];
		return t;
	};
	_proto._Image5_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "cafe_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Group6_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 156.68;
		t.layout = this._BasicLayout4_i();
		t.elementsContent = [this.sm7_i(),this.sm8_i()];
		return t;
	};
	_proto._BasicLayout4_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm7_i = function () {
		var t = new SmallMachine();
		this.sm7 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm8_i = function () {
		var t = new SmallMachine();
		this.sm8 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto._Group7_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 494.58;
		t.layout = this._BasicLayout5_i();
		t.elementsContent = [this.sm9_i(),this.sm10_i()];
		return t;
	};
	_proto._BasicLayout5_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm9_i = function () {
		var t = new SmallMachine();
		this.sm9 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm10_i = function () {
		var t = new SmallMachine();
		this.sm10 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto._Group8_i = function () {
		var t = new eui.Group();
		t.horizontalCenter = 0;
		t.y = 833.97;
		t.layout = this._BasicLayout6_i();
		t.elementsContent = [this.sm11_i(),this.sm12_i()];
		return t;
	};
	_proto._BasicLayout6_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sm11_i = function () {
		var t = new SmallMachine();
		this.sm11 = t;
		t.left = 0;
		t.top = 0;
		return t;
	};
	_proto.sm12_i = function () {
		var t = new SmallMachine();
		this.sm12 = t;
		t.x = 260;
		t.y = 0;
		return t;
	};
	_proto.bottomGroup_i = function () {
		var t = new eui.Group();
		this.bottomGroup = t;
		t.bottom = 0;
		t.height = 200;
		t.left = 0;
		t.right = 0;
		t.elementsContent = [this._Image6_i(),this._Group10_i()];
		return t;
	};
	_proto._Image6_i = function () {
		var t = new eui.Image();
		t.left = 0;
		t.right = 0;
		t.source = "game_bg01_png";
		t.y = 0;
		return t;
	};
	_proto._Group10_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.layout = this._HorizontalLayout2_i();
		t.elementsContent = [this.bt1_i(),this.bt2_i(),this.bt3_i(),this.bt4_i(),this.bt5_i()];
		return t;
	};
	_proto._HorizontalLayout2_i = function () {
		var t = new eui.HorizontalLayout();
		t.gap = 40;
		t.horizontalAlign = "center";
		t.verticalAlign = "middle";
		return t;
	};
	_proto.bt1_i = function () {
		var t = new Bottle();
		this.bt1 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 124;
		t.y = 60;
		return t;
	};
	_proto.bt2_i = function () {
		var t = new Bottle();
		this.bt2 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 134;
		t.y = 70;
		return t;
	};
	_proto.bt3_i = function () {
		var t = new Bottle();
		this.bt3 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 144;
		t.y = 80;
		return t;
	};
	_proto.bt4_i = function () {
		var t = new Bottle();
		this.bt4 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 154;
		t.y = 90;
		return t;
	};
	_proto.bt5_i = function () {
		var t = new Bottle();
		this.bt5 = t;
		t.scaleX = 1;
		t.scaleY = 1;
		t.x = 164;
		t.y = 100;
		return t;
	};
	_proto.cdGroup1_i = function () {
		var t = new eui.Group();
		this.cdGroup1 = t;
		t.anchorOffsetX = 98;
		t.anchorOffsetY = 98;
		t.scaleX = 0.2;
		t.scaleY = 0.2;
		t.verticalCenter = 0;
		t.x = 376;
		t.elementsContent = [this._Image7_i(),this._Label1_i()];
		return t;
	};
	_proto._Image7_i = function () {
		var t = new eui.Image();
		t.source = "game_cd_png";
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.horizontalCenter = 0;
		t.size = 100;
		t.text = "1";
		t.verticalCenter = 0;
		return t;
	};
	_proto.cdGroup0_i = function () {
		var t = new eui.Group();
		this.cdGroup0 = t;
		t.anchorOffsetX = 98;
		t.anchorOffsetY = 98;
		t.scaleX = 0.2;
		t.scaleY = 0.2;
		t.verticalCenter = 0;
		t.x = 376;
		t.elementsContent = [this._Image8_i(),this._Label2_i()];
		return t;
	};
	_proto._Image8_i = function () {
		var t = new eui.Image();
		t.source = "game_cd_png";
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.horizontalCenter = 0;
		t.size = 100;
		t.text = "2";
		t.verticalCenter = 0;
		return t;
	};
	_proto.cdGroup_i = function () {
		var t = new eui.Group();
		this.cdGroup = t;
		t.anchorOffsetX = 98;
		t.anchorOffsetY = 98;
		t.scaleX = 0.2;
		t.scaleY = 0.2;
		t.verticalCenter = 0;
		t.x = 376;
		t.elementsContent = [this._Image9_i(),this._Label3_i()];
		return t;
	};
	_proto._Image9_i = function () {
		var t = new eui.Image();
		t.source = "game_cd_png";
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.horizontalCenter = 0;
		t.size = 100;
		t.text = "3";
		t.verticalCenter = 0;
		return t;
	};
	_proto.leftBtn_i = function () {
		var t = new eui.Button();
		this.leftBtn = t;
		t.label = "";
		t.left = 0;
		t.verticalCenter = 0;
		t.skinName = GameSkin$Skin1;
		return t;
	};
	_proto.rightBtn_i = function () {
		var t = new eui.Button();
		this.rightBtn = t;
		t.label = "";
		t.right = 0;
		t.verticalCenter = 0;
		t.skinName = GameSkin$Skin2;
		return t;
	};
	_proto._Group13_i = function () {
		var t = new eui.Group();
		t.right = -3;
		t.top = 0;
		t.width = 446;
		t.layout = this._HorizontalLayout3_i();
		t.elementsContent = [this._Group11_i(),this._Group12_i()];
		return t;
	};
	_proto._HorizontalLayout3_i = function () {
		var t = new eui.HorizontalLayout();
		return t;
	};
	_proto._Group11_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 48;
		t.width = 197.33;
		t.x = 0;
		t.y = 15;
		t.elementsContent = [this._Image10_i(),this._Label4_i(),this.timeLab_i()];
		return t;
	};
	_proto._Image10_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(57,11,348,70);
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "game_bg2_png";
		t.top = 0;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.left = 10;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "TIME";
		t.textColor = 0x000000;
		t.verticalCenter = 0;
		return t;
	};
	_proto.timeLab_i = function () {
		var t = new eui.Label();
		this.timeLab = t;
		t.right = 20;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "20:00";
		t.textColor = 0x000000;
		t.verticalCenter = 0;
		return t;
	};
	_proto._Group12_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.height = 48;
		t.right = 0;
		t.width = 249.33;
		t.y = 0;
		t.elementsContent = [this._Image11_i(),this._Label5_i(),this.scoreLab_i()];
		return t;
	};
	_proto._Image11_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scale9Grid = new egret.Rectangle(57,11,348,70);
		t.source = "game_bg2_png";
		t.top = 0;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.left = 10;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "SCORE";
		t.textColor = 0x000000;
		t.verticalCenter = 0;
		return t;
	};
	_proto.scoreLab_i = function () {
		var t = new eui.Label();
		this.scoreLab = t;
		t.right = 15;
		t.scaleX = 1;
		t.scaleY = 1;
		t.text = "0";
		t.textColor = 0x000000;
		t.verticalCenter = 0;
		return t;
	};
	return GameSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/LoadingSkin.exml'] = window.LoadingSkin = (function (_super) {
	__extends(LoadingSkin, _super);
	function LoadingSkin() {
		_super.call(this);
		this.skinParts = [];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = LoadingSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.top = 0;
		t.elementsContent = [this._Image1_i(),this._Image2_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "loading_bg_png";
		t.top = 0;
		return t;
	};
	_proto._Image2_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0.5;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "loading_logo_png";
		t.verticalCenter = -120;
		return t;
	};
	return LoadingSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/OrderUISkin.exml'] = window.OrderUISkin = (function (_super) {
	__extends(OrderUISkin, _super);
	function OrderUISkin() {
		_super.call(this);
		this.skinParts = ["order1","order2","order3","order4"];
		
		this.height = 154;
		this.width = 607;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = OrderUISkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this._Image1_i(),this.order1_i(),this.order2_i(),this.order3_i(),this.order4_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "game_top_png";
		return t;
	};
	_proto.order1_i = function () {
		var t = new FoodOrder();
		this.order1 = t;
		t.x = 26.68;
		t.y = 10;
		return t;
	};
	_proto.order2_i = function () {
		var t = new FoodOrder();
		this.order2 = t;
		t.x = 168;
		t.y = 10;
		return t;
	};
	_proto.order3_i = function () {
		var t = new FoodOrder();
		this.order3 = t;
		t.x = 309;
		t.y = 10;
		return t;
	};
	_proto.order4_i = function () {
		var t = new FoodOrder();
		this.order4 = t;
		t.x = 450;
		t.y = 10;
		return t;
	};
	return OrderUISkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/ResultSkin.exml'] = window.ResultSkin = (function (_super) {
	__extends(ResultSkin, _super);
	var ResultSkin$Skin3 = 	(function (_super) {
		__extends(ResultSkin$Skin3, _super);
		function ResultSkin$Skin3() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
						new eui.SetProperty("_Image1","source","result_retry_btn_png")
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ResultSkin$Skin3.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			this._Image1 = t;
			t.percentHeight = 100;
			t.source = "result_retry_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ResultSkin$Skin3;
	})(eui.Skin);

	var ResultSkin$Skin4 = 	(function (_super) {
		__extends(ResultSkin$Skin4, _super);
		function ResultSkin$Skin4() {
			_super.call(this);
			this.skinParts = ["labelDisplay"];
			
			this.elementsContent = [this._Image1_i(),this.labelDisplay_i()];
			this.states = [
				new eui.State ("up",
					[
					])
				,
				new eui.State ("down",
					[
					])
				,
				new eui.State ("disabled",
					[
					])
			];
		}
		var _proto = ResultSkin$Skin4.prototype;

		_proto._Image1_i = function () {
			var t = new eui.Image();
			t.percentHeight = 100;
			t.source = "result_share_btn_png";
			t.percentWidth = 100;
			return t;
		};
		_proto.labelDisplay_i = function () {
			var t = new eui.Label();
			this.labelDisplay = t;
			t.horizontalCenter = 0;
			t.verticalCenter = 0;
			return t;
		};
		return ResultSkin$Skin4;
	})(eui.Skin);

	function ResultSkin() {
		_super.call(this);
		this.skinParts = ["retryBtn","shareBtn","c","c1","c2","c3","c4","c5","s","s1","s2","s3","s4","s5","totallLab"];
		
		this.height = 1334;
		this.width = 750;
		this.elementsContent = [this._Image1_i(),this.retryBtn_i(),this.shareBtn_i(),this._Label1_i(),this._Label2_i(),this._Label3_i(),this._Label4_i(),this._Label5_i(),this._Label6_i(),this._Label7_i(),this._Label8_i(),this.c_i(),this.c1_i(),this.c2_i(),this.c3_i(),this.c4_i(),this.c5_i(),this.s_i(),this.s1_i(),this.s2_i(),this.s3_i(),this.s4_i(),this.s5_i(),this.totallLab_i()];
	}
	var _proto = ResultSkin.prototype;

	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.bottom = 0;
		t.left = 0;
		t.right = 0;
		t.source = "result_bg_png";
		t.top = 0;
		return t;
	};
	_proto.retryBtn_i = function () {
		var t = new eui.Button();
		this.retryBtn = t;
		t.label = "";
		t.left = 160;
		t.y = 1178;
		t.skinName = ResultSkin$Skin3;
		return t;
	};
	_proto.shareBtn_i = function () {
		var t = new eui.Button();
		this.shareBtn = t;
		t.label = "";
		t.right = 160;
		t.y = 1178;
		t.skinName = ResultSkin$Skin4;
		return t;
	};
	_proto._Label1_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.text = "Try again";
		t.textColor = 0x000000;
		t.x = 150;
		t.y = 1277;
		return t;
	};
	_proto._Label2_i = function () {
		var t = new eui.Label();
		t.bold = true;
		t.text = "Share";
		t.textColor = 0x000000;
		t.x = 509;
		t.y = 1277;
		return t;
	};
	_proto._Label3_i = function () {
		var t = new eui.Label();
		t.text = "奶油";
		t.textColor = 0x000000;
		t.x = 203;
		t.y = 518;
		return t;
	};
	_proto._Label4_i = function () {
		var t = new eui.Label();
		t.size = 20;
		t.text = "NO.00002";
		t.textColor = 0x000000;
		t.x = 119;
		t.y = 222;
		return t;
	};
	_proto._Label5_i = function () {
		var t = new eui.Label();
		t.text = "栗子";
		t.textColor = 0x000000;
		t.x = 203;
		t.y = 557;
		return t;
	};
	_proto._Label6_i = function () {
		var t = new eui.Label();
		t.text = "桂花";
		t.textColor = 0x000000;
		t.x = 203;
		t.y = 597;
		return t;
	};
	_proto._Label7_i = function () {
		var t = new eui.Label();
		t.text = "坚果";
		t.textColor = 0x000000;
		t.x = 203;
		t.y = 636;
		return t;
	};
	_proto._Label8_i = function () {
		var t = new eui.Label();
		t.text = "糖";
		t.textColor = 0x000000;
		t.x = 203;
		t.y = 675.32;
		return t;
	};
	_proto.c_i = function () {
		var t = new eui.Label();
		this.c = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 459.95;
		return t;
	};
	_proto.c1_i = function () {
		var t = new eui.Label();
		this.c1 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 518;
		return t;
	};
	_proto.c2_i = function () {
		var t = new eui.Label();
		this.c2 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 557;
		return t;
	};
	_proto.c3_i = function () {
		var t = new eui.Label();
		this.c3 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 596;
		return t;
	};
	_proto.c4_i = function () {
		var t = new eui.Label();
		this.c4 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 635;
		return t;
	};
	_proto.c5_i = function () {
		var t = new eui.Label();
		this.c5 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 353;
		t.y = 674.6;
		return t;
	};
	_proto.s_i = function () {
		var t = new eui.Label();
		this.s = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 540.3;
		t.y = 457.97;
		return t;
	};
	_proto.s1_i = function () {
		var t = new eui.Label();
		this.s1 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 543.63;
		t.y = 518;
		return t;
	};
	_proto.s2_i = function () {
		var t = new eui.Label();
		this.s2 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 544.98;
		t.y = 557;
		return t;
	};
	_proto.s3_i = function () {
		var t = new eui.Label();
		this.s3 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 545.98;
		t.y = 596;
		return t;
	};
	_proto.s4_i = function () {
		var t = new eui.Label();
		this.s4 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 543.98;
		t.y = 635;
		return t;
	};
	_proto.s5_i = function () {
		var t = new eui.Label();
		this.s5 = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 545.98;
		t.y = 674.35;
		return t;
	};
	_proto.totallLab_i = function () {
		var t = new eui.Label();
		this.totallLab = t;
		t.text = "*30";
		t.textColor = 0x000000;
		t.x = 547.99;
		t.y = 794.58;
		return t;
	};
	return ResultSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/SmallCupSkin.exml'] = window.SmallCupSkin = (function (_super) {
	__extends(SmallCupSkin, _super);
	function SmallCupSkin() {
		_super.call(this);
		this.skinParts = ["scuping00","sfull","smask","scuping","scupingmk","sfree","sfullwhater","swhater","scup","bfull","bmask","bcuping","bcupingmk","bfree","bfullwhater","bwhater","bcup"];
		
		this.height = 116;
		this.width = 83;
		this.elementsContent = [this._Group1_i()];
	}
	var _proto = SmallCupSkin.prototype;

	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 116;
		t.width = 83;
		t.elementsContent = [this.scup_i(),this.bcup_i()];
		return t;
	};
	_proto.scup_i = function () {
		var t = new eui.Group();
		this.scup = t;
		t.bottom = 0;
		t.height = 97;
		t.visible = false;
		t.width = 83;
		t.x = 0;
		t.elementsContent = [this.scuping00_i(),this.sfull_i(),this.smask_i(),this.scuping_i(),this.scupingmk_i(),this.sfree_i(),this.sfullwhater_i(),this.swhater_i()];
		return t;
	};
	_proto.scuping00_i = function () {
		var t = new eui.Image();
		this.scuping00 = t;
		t.bottom = -4;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.x = 0;
		return t;
	};
	_proto.sfull_i = function () {
		var t = new eui.Image();
		this.sfull = t;
		t.bottom = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete0_png";
		t.visible = false;
		return t;
	};
	_proto.smask_i = function () {
		var t = new eui.Image();
		this.smask = t;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.height = 90;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.width = 75;
		return t;
	};
	_proto.scuping_i = function () {
		var t = new eui.Image();
		this.scuping = t;
		t.bottom = -4;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.x = 0;
		return t;
	};
	_proto.scupingmk_i = function () {
		var t = new eui.Image();
		this.scupingmk = t;
		t.bottom = -4;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		t.x = 0;
		return t;
	};
	_proto.sfree_i = function () {
		var t = new eui.Image();
		this.sfree = t;
		t.bottom = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete1_png";
		t.x = 0;
		return t;
	};
	_proto.sfullwhater_i = function () {
		var t = new eui.Rect();
		this.sfullwhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x7C2F2F;
		t.height = 2;
		t.left = 0;
		t.mask = this.scuping;
		t.right = 0;
		t.top = 8;
		return t;
	};
	_proto.swhater_i = function () {
		var t = new eui.Rect();
		this.swhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fillColor = 0x3C0000;
		t.height = 2;
		t.left = 0;
		t.mask = this.smask;
		t.right = 0;
		return t;
	};
	_proto.bcup_i = function () {
		var t = new eui.Group();
		this.bcup = t;
		t.height = 116;
		t.horizontalCenter = 0;
		t.width = 67;
		t.y = 0;
		t.elementsContent = [this.bfull_i(),this.bmask_i(),this.bcuping_i(),this.bcupingmk_i(),this.bfree_i(),this.bfullwhater_i(),this.bwhater_i()];
		return t;
	};
	_proto.bfull_i = function () {
		var t = new eui.Image();
		this.bfull = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete0_png";
		t.visible = false;
		return t;
	};
	_proto.bmask_i = function () {
		var t = new eui.Image();
		this.bmask = t;
		t.bottom = 0;
		t.height = 109;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.visible = false;
		t.width = 60;
		return t;
	};
	_proto.bcuping_i = function () {
		var t = new eui.Image();
		this.bcuping = t;
		t.bottom = -3;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		return t;
	};
	_proto.bcupingmk_i = function () {
		var t = new eui.Image();
		this.bcupingmk = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = -3;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.visible = false;
		return t;
	};
	_proto.bfree_i = function () {
		var t = new eui.Image();
		this.bfree = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete1_png";
		t.visible = false;
		return t;
	};
	_proto.bfullwhater_i = function () {
		var t = new eui.Rect();
		this.bfullwhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.fillColor = 0x7C2F2F;
		t.height = 2;
		t.left = 0;
		t.mask = this.scuping;
		t.right = 0;
		t.top = 8;
		return t;
	};
	_proto.bwhater_i = function () {
		var t = new eui.Rect();
		this.bwhater = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.bottom = 0;
		t.fillColor = 0x3C0000;
		t.height = 2;
		t.left = 0;
		t.mask = this.smask;
		t.right = 0;
		return t;
	};
	return SmallCupSkin;
})(eui.Skin);generateEUI.paths['resource/eui_skins/SmallMachineSkin.exml'] = window.SmallMachineSkin = (function (_super) {
	__extends(SmallMachineSkin, _super);
	function SmallMachineSkin() {
		_super.call(this);
		this.skinParts = ["notImg","inputImg","delImg","packageImg","operationGroup","cup","leftwhater","rightwhater","fd2","fd1","sfull","bfull","sdel","bdel","xxx"];
		
		this.elementsContent = [this._Group4_i()];
	}
	var _proto = SmallMachineSkin.prototype;

	_proto._Group4_i = function () {
		var t = new eui.Group();
		t.elementsContent = [this._Image1_i(),this.operationGroup_i(),this.cup_i(),this.leftwhater_i(),this.rightwhater_i(),this._Group1_i(),this._Group2_i(),this._Group3_i()];
		return t;
	};
	_proto._Image1_i = function () {
		var t = new eui.Image();
		t.horizontalCenter = 0;
		t.scaleX = -1;
		t.source = "smal_cafe_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.operationGroup_i = function () {
		var t = new eui.Group();
		this.operationGroup = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 98;
		t.width = 62;
		t.x = 105;
		t.y = 3;
		t.elementsContent = [this.notImg_i(),this.inputImg_i(),this.delImg_i(),this.packageImg_i()];
		return t;
	};
	_proto.notImg_i = function () {
		var t = new eui.Image();
		this.notImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon66_noinput_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.inputImg_i = function () {
		var t = new eui.Image();
		this.inputImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_input_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.delImg_i = function () {
		var t = new eui.Image();
		this.delImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_del_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.packageImg_i = function () {
		var t = new eui.Image();
		this.packageImg = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "icon_cafe_input_png";
		t.verticalCenter = 0;
		return t;
	};
	_proto.cup_i = function () {
		var t = new SmallCup();
		this.cup = t;
		t.x = 96;
		t.y = 141;
		return t;
	};
	_proto.leftwhater_i = function () {
		var t = new eui.Image();
		this.leftwhater = t;
		t.height = 115;
		t.source = "cafe_whatering_png";
		t.x = 121;
		t.y = 139;
		return t;
	};
	_proto.rightwhater_i = function () {
		var t = new eui.Image();
		this.rightwhater = t;
		t.height = 115;
		t.source = "cafe_whatering_png";
		t.x = 150;
		t.y = 139;
		return t;
	};
	_proto._Group1_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 100;
		t.width = 39;
		t.x = 119;
		t.y = 154;
		t.layout = this._VerticalLayout1_i();
		t.elementsContent = [this.fd2_i(),this.fd1_i()];
		return t;
	};
	_proto._VerticalLayout1_i = function () {
		var t = new eui.VerticalLayout();
		t.horizontalAlign = "center";
		t.paddingBottom = 0;
		t.verticalAlign = "middle";
		return t;
	};
	_proto.fd2_i = function () {
		var t = new eui.Image();
		this.fd2 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.source = "";
		t.width = 37;
		t.x = 4;
		t.y = 43;
		return t;
	};
	_proto.fd1_i = function () {
		var t = new eui.Image();
		this.fd1 = t;
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.height = 37;
		t.source = "";
		t.width = 37;
		t.x = 1;
		t.y = 57;
		return t;
	};
	_proto._Group2_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.width = 103;
		t.x = 86;
		t.y = 140.5;
		t.layout = this._BasicLayout1_i();
		t.elementsContent = [this.sfull_i(),this.bfull_i()];
		return t;
	};
	_proto._BasicLayout1_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sfull_i = function () {
		var t = new eui.Image();
		this.sfull = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_complete0_png";
		t.visible = false;
		return t;
	};
	_proto.bfull_i = function () {
		var t = new eui.Image();
		this.bfull = t;
		t.anchorOffsetX = 0;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_complete0_png";
		t.visible = false;
		t.width = 83.5;
		return t;
	};
	_proto._Group3_i = function () {
		var t = new eui.Group();
		t.anchorOffsetX = 0;
		t.anchorOffsetY = 0;
		t.x = 99;
		t.y = 143.5;
		t.layout = this._BasicLayout2_i();
		t.elementsContent = [this.sdel_i(),this.bdel_i(),this.xxx_i()];
		return t;
	};
	_proto._BasicLayout2_i = function () {
		var t = new eui.BasicLayout();
		return t;
	};
	_proto.sdel_i = function () {
		var t = new eui.Image();
		this.sdel = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "small_cup_geting_png";
		t.visible = false;
		return t;
	};
	_proto.bdel_i = function () {
		var t = new eui.Image();
		this.bdel = t;
		t.bottom = 0;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "big_cup_geting_png";
		t.visible = false;
		return t;
	};
	_proto.xxx_i = function () {
		var t = new eui.Image();
		this.xxx = t;
		t.horizontalCenter = 0;
		t.scaleX = 1;
		t.scaleY = 1;
		t.source = "xxx_png";
		t.verticalCenter = 9;
		t.visible = false;
		return t;
	};
	return SmallMachineSkin;
})(eui.Skin);